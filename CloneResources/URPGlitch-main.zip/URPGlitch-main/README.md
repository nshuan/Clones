# URPGlitch
urp glitch package based on mao-test-h's project
please use this link for tutorial https://youtu.be/CW7L2XQq7tk

simple steps:
1. import the package to a urp project
2. modify the renderer to have the glitch renderer feature, analog or digital
3. attach the appropriate shaders to them in the slots availiable in renderer features added
4. create a volume component and use the profile given in package to set up the effect, you can create the volume by attaching the volume componenet to any gameobject
5. turn on post process on your main camera and enable fxaa anti aliasing. for some reason smaa and none doesnt work.
6.it should work now, try moving the sliders around to change the effect.
7. if there are any issues follow my video tutorial above or contact me using comments or other links
